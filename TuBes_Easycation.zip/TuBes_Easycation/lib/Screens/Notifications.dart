import 'package:flutter/material.dart';
import 'package:easycation_tubes/utils/TextStyles.dart';
import 'package:easycation_tubes/utils/consts.dart';

class Notifications extends StatefulWidget {
  @override
  _NotificationsState createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: kwhite,
        appBar: AppBar(
          backgroundColor: kwhite,
          title: BoldText("My Notifications", 25, kblack),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              notification(),
              notification2(),
              notification3(),
              notification4()
            ],
          ),
        ));
  }

  Padding notification() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        height: 100,
        child: Card(
          elevation: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    BoldText("Termurah di Bandung!", 20.0, kblack),
                    Icon(
                      Icons.more_horiz,
                      size: 20.0,
                      color: kblack,
                    )
                  ],
                ),
                NormalText("Penginapan murah, fasilitas lengkap, gas keun!",
                    kgreyDark, 16),
                NormalText("07,Mar at 15:30 pm", kdarkBlue, 12),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Padding notification2() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        height: 100,
        child: Card(
          elevation: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    BoldText("Wisata baru di Bandung!", 20.0, kblack),
                    Icon(
                      Icons.more_horiz,
                      size: 20.0,
                      color: kblack,
                    )
                  ],
                ),
                NormalText(
                    "Ada wisata baru nih di Bandung, cek yuk!", kgreyDark, 16),
                NormalText("07,Mar at 15:30 pm", kdarkBlue, 12),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Padding notification3() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        height: 100,
        child: Card(
          elevation: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    BoldText("Diskon Besar Nih!", 20.0, kblack),
                    Icon(
                      Icons.more_horiz,
                      size: 20.0,
                      color: kblack,
                    )
                  ],
                ),
                NormalText("Ada diskon besar dari Caladan Hotel, cek di sini.",
                    kgreyDark, 16),
                NormalText("07,Mar at 15:30 pm", kdarkBlue, 12),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Padding notification4() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        height: 100,
        child: Card(
          elevation: 1,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    BoldText("Gratis Tiket!", 20.0, kblack),
                    Icon(
                      Icons.more_horiz,
                      size: 20.0,
                      color: kblack,
                    )
                  ],
                ),
                NormalText("Gratis tiket masuk Floating Market, cek di sini.",
                    kgreyDark, 16),
                NormalText("07,Mar at 15:30 pm", kdarkBlue, 12),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
