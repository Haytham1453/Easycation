import 'package:flutter/cupertino.dart';
import 'package:easycation_tubes/utils/consts.dart';

class Slider {
  final String sliderImageUrl;
  final String sliderHeading;
  final String sliderSubHeading;

  Slider(
      {@required this.sliderImageUrl,
      @required this.sliderHeading,
      @required this.sliderSubHeading});
}

final sliderArrayList = [
  Slider(
      sliderImageUrl: 'assets/saturev.png',
      sliderHeading: SLIDER_HEADING_1,
      sliderSubHeading:
          "Temukan tempat wisata yang ingin kamu kunjungi dan booking tiketnya dengan mudah."),
  Slider(
      sliderImageUrl: 'assets/two.png',
      sliderHeading: SLIDER_HEADING_2,
      sliderSubHeading:
          "Temukan juga tempat penginapan terbaik dan booking tempatnya dengan mudah."),
  Slider(
      sliderImageUrl: 'assets/three.png',
      sliderHeading: SLIDER_HEADING_3,
      sliderSubHeading: "Easycation mempermudah perjalanan pariwisata anda."),
];
