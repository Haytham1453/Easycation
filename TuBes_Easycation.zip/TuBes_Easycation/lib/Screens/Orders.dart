import 'package:flutter/material.dart';
import 'package:easycation_tubes/utils/RecommendationImage.dart';
import 'package:easycation_tubes/utils/TextStyles.dart';
import 'package:easycation_tubes/utils/consts.dart';

class Orders extends StatefulWidget {
  @override
  _OrdersState createState() => _OrdersState();
}

class _OrdersState extends State<Orders> with SingleTickerProviderStateMixin {
  TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = new TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();
    tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kwhite,
        title: BoldText("My Orders", 25, kblack),
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Scaffold(
        backgroundColor: kwhite,
        appBar: TabBar(
          labelColor: kdarkBlue,
          labelStyle:
              TextStyle(fontFamily: "nunito", fontWeight: FontWeight.bold),
          controller: tabController,
          indicatorColor: kdarkBlue,
          tabs: <Widget>[
            Tab(text: "Tiket Pariwisata"),
            Tab(text: "Penginapan"),
          ],
        ),
        body: TabBarView(
          children: <Widget>[
            //Icon(Icons.person),
            SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        BoldText("Current order", 20.0, kblack),
                        BoldText("More", 16, kdarkBlue),
                      ],
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width - 80,
                      height: 250,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width - 80,
                            height: 200.0,
                            child: ClipRRect(
                                borderRadius: new BorderRadius.all(
                                  Radius.circular(15),
                                ),
                                child: Image.asset(
                                  "assets/tangkubanparahu.jpg",
                                  fit: BoxFit.fitHeight,
                                )),
                          ),
                          BoldText("Tangkuban Parahu", 20.0, kblack),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              NormalText("Lembang", kgreyDark, 12.0),
                              Icon(
                                Icons.location_on,
                                color: kgreyDark,
                                size: 16.0,
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        BoldText("Past order", 20.0, kblack),
                        BoldText("More", 16, kdarkBlue),
                      ],
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Container(
                      width: 400,
                      height: 200,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: <Widget>[
                          RecommendationImage("assets/tangkubanparahu.jpg",
                              "Tangkuban Parahu", "Kab. Bandung"),
                          RecommendationImage(
                              "assets/orchid.jpg", "Orchid Forest", "Lembang"),
                          RecommendationImage("assets/kawahputih.jpg",
                              "Kawah Putih", "Ciwidey"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        BoldText("Current order", 20.0, kblack),
                        BoldText("More", 16, kdarkBlue),
                      ],
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width - 80,
                      height: 250,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width - 80,
                            height: 200.0,
                            child: ClipRRect(
                                borderRadius: new BorderRadius.all(
                                  Radius.circular(15),
                                ),
                                child: Image.asset(
                                  "assets/grandparadise.jpg",
                                  fit: BoxFit.fitHeight,
                                )),
                          ),
                          BoldText("Grand Paradise", 20.0, kblack),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              NormalText("Lembang", kgreyDark, 12.0),
                              Icon(
                                Icons.location_on,
                                color: kgreyDark,
                                size: 16.0,
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        BoldText("Past order", 20.0, kblack),
                        BoldText("More", 16, kdarkBlue),
                      ],
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Container(
                      width: 400,
                      height: 200,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: <Widget>[
                          RecommendationImage("assets/grandparadise.jpg",
                              "Grand Paradise", "Lembang"),
                          RecommendationImage(
                              "assets/pesona.jpg", "Pesona Bamboe", "Lembang"),
                          RecommendationImage(
                              "assets/green.jpg", "Horison Green", "Lembang"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          controller: tabController,
        ),
      ),
    );
  }
}
